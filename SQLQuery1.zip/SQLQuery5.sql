
-- Q5. Number of month present in dataset

SELECT count(DISTINCT MONTH (Date)) AS month_present from analysis.dbo.[Corona Virus Dataset];