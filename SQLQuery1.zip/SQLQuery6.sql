
-- Q6. Find monthly average for confirmed, deaths, recovered
SELECT 
    
    MONTH(Date) AS Month,
    AVG(Confirmed) AS Avg_Confirmed,
    AVG(Deaths) AS Avg_Deaths,
    AVG(Recovered) AS Avg_Recovered
FROM 
    analysis.dbo.[Corona Virus Dataset]
GROUP BY 
     MONTH(Date)
ORDER BY 
     Month;