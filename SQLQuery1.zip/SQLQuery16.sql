
-- Q15. Find Country having lowest number of the death case

 
 SELECT distinct(Country_Region),MIN(Confirmed) as MIN_values from analysis.dbo.[Corona Virus Dataset]
 group by Country_Region;
