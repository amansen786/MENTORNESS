

-- Q12.Check how corona virus spread out with respect to death case per month
--      (Eg.: total confirmed cases, their average, variance & STDEV )
 
 SELECT 
    
    MONTH(Date) AS month,
    SUM(Deaths) AS total_death_cases,
    AVG(Deaths) AS average_death_cases,
    VAR(Deaths) AS variance_death_cases
    
FROM 
    analysis.dbo.[Corona Virus Dataset]
GROUP BY 
     MONTH(Date)
ORDER BY 
    month;