
-- Q4. Check what is start_date and end_date

SELECT MIN(Date) AS Start_date,
MAX(Date) AS End_date FROM analysis.dbo.[Corona Virus Dataset];