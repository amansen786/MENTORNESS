
-- Q1. Write a code to check NULL values
 
 SELECT *
FROM analysis.dbo.[Corona Virus Dataset]
WHERE Province IS NULL
   OR Country_Region IS NULL
   OR Date IS NULL
   OR Confirmed IS NULL
   OR Deaths IS NULL
   OR Recovered IS NULL;


   

