
-- Q13. Check how corona virus spread out with respect to recovered case
--      (Eg.: total confirmed cases, their average, variance & STDEV )


SELECT 
    
    MONTH(Date) AS month,
    SUM(Recovered) AS total_Recovered_cases,
    AVG(Recovered) AS average_Recovered_cases,
    VAR(Recovered) AS variance_Recovered_cases
    
FROM 
    analysis.dbo.[Corona Virus Dataset]
GROUP BY 
     MONTH(Date)
ORDER BY 
    month;