
--Q2. If NULL values are present, update them with zeros for all columns. 

-- ANSWER-- there is no NULL Values in this Dataset
