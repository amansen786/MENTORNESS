
-- Q7. Find most frequent value for confirmed, deaths, recovered each month 

WITH MonthlyCounts AS (
    SELECT 
        YEAR(Date) AS year,
        MONTH(Date) AS month,
        Confirmed,
        Deaths,
        Recovered,
        ROW_NUMBER() OVER (PARTITION BY YEAR(Date), MONTH(Date) ORDER BY COUNT(*) DESC) AS rn
    FROM 
        analysis.dbo.[Corona Virus Dataset]
    GROUP BY 
        YEAR(Date), MONTH(Date), Confirmed, Deaths, Recovered
)
SELECT 
    year,
    month,
    confirmed,
    deaths,
    recovered
FROM 
    MonthlyCounts
WHERE 
    rn = 1;
